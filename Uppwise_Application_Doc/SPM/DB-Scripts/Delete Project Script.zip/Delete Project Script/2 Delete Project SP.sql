
--DROP PROCEDURE DeleteProject
--GO
Alter PROCEDURE dbo.DeleteProject(@cprog NUMERIC(18,0))
AS 
Begin
BEGIN TRANSACTION 
begin try
--declare @cprog as integer
--set @cprog = -1

DECLARE allProjectCur CURSOR read_only FOR 
        Select c_prog =  C_PROG  from PROG_T056
				where C_PROG not in (select C_PROG from bpm_objects where f_id=10  )
				and IS_PF_PROJECT is null 

      --OPEN CURSOR.   
      OPEN allProjectCur 

      --FETCH THE RECORD INTO THE VARIABLES.   
      FETCH next FROM allProjectCur INTO @cprog
	   WHILE @@FETCH_STATUS = 0 
	   BEGIN

        
				DELETE FROM PF_TAB_Projects_Ascn WHERE C_PROG = @cprog

               DELETE FROM PF_TAB_Projects_CBElements WHERE C_PROG = @cprog

               DELETE FROM PF_TAB_Projects_Financial_Data WHERE C_PROG = @cprog

               DELETE FROM PF_TAB_Projects_Financial_Plan WHERE C_PROG = @cprog

               DELETE FROM PF_TAB_Projects_Metrics_Values WHERE C_PROG = @cprog


               DELETE FROM PF_TAB_Projects_Resources_Data WHERE C_PROG = @cprog

               DELETE FROM PF_TAB_Projects_Resources_Plan WHERE C_PROG = @cprog

               DELETE FROM Tab_Risk_Master WHERE C_PROG = @cprog

               DELETE FROM TAB_CONTRACTS WHERE C_PROG = @cprog

               DELETE FROM ASCN_GRP_PROG_T070 WHERE C_PROG = @cprog

               DELETE FROM ASCN_GRP_PROG_TT WHERE C_PROG = @cprog

               DELETE FROM ASCN_ITEM_T112 WHERE C_PROG = @cprog

               DELETE FROM ASCN_NODO_PROG_T110 WHERE C_PROG = @cprog

               DELETE FROM ASCN_NODO_TASK_T038 WHERE C_PROG = @cprog

               DELETE FROM ASCN_NODO_TRAK_T101 WHERE C_PROG = @cprog

               DELETE FROM ASCN_STRU_T021 WHERE C_PROG = @cprog

               DELETE FROM ASCN_UTEN_PROG_T071 WHERE C_PROG = @cprog

               DELETE FROM ASCN_UTEN_PROG_TT WHERE C_PROG = @cprog

               DELETE FROM BDG_REV_T089 WHERE C_PROG = @cprog

               DELETE FROM BDG_T029 WHERE C_PROG = @cprog

               DELETE FROM CONS_T059 WHERE C_PROG = @cprog

               DELETE FROM COSTO_AGRT_T022 WHERE C_PROG = @cprog

               DELETE FROM PROG_TRACK_STOR_T102 WHERE C_PROG = @cprog

               DELETE FROM PROG_TRACK_T091 WHERE C_PROG = @cprog

               DELETE FROM ITEM_PRJ_T097 WHERE C_PROG = @cprog

               DELETE FROM CRV_DSBN_T013 WHERE C_PROG = @cprog

               DELETE FROM DATO_CRV_T068 WHERE C_PROG = @cprog

               DELETE FROM DEFN_LVL_STRU_T014 WHERE C_PROG = @cprog

               DELETE FROM DEFN_STRU_T012 WHERE C_PROG = @cprog

               DELETE FROM DSBN_COSTO_T090 WHERE C_PROG = @cprog

               DELETE FROM DSBN_PE_T129 WHERE C_PROG = @cprog

               DELETE FROM EVNT_ATVT_T038 WHERE C_PROG = @cprog

               DELETE FROM EVNT_T040 WHERE C_PROG = @cprog

               DELETE FROM FAT_T092 WHERE C_PROG = @cprog

               DELETE FROM MLSTN_CONTR_T119 WHERE C_PROG = @cprog


               DELETE FROM MSP_ASSIGNMENTS WHERE PROJ_ID = @cprog

               DELETE FROM MSP_ATTRIBUTE_STRINGS WHERE PROJ_ID = @cprog

               DELETE FROM MSP_AVAILABILITY WHERE PROJ_ID = @cprog

               DELETE FROM MSP_CALENDAR_DATA WHERE PROJ_ID = @cprog

               DELETE FROM MSP_CALENDARS WHERE PROJ_ID = @cprog

               DELETE FROM MSP_CODE_FIELDS WHERE PROJ_ID = @cprog

               DELETE FROM MSP_DATE_FIELDS WHERE PROJ_ID = @cprog

               DELETE FROM MSP_DURATION_FIELDS WHERE PROJ_ID = @cprog

               DELETE FROM MSP_FIELD_ATTRIBUTES WHERE PROJ_ID = @cprog

               DELETE FROM MSP_FLAG_FIELDS WHERE PROJ_ID = @cprog

               DELETE FROM MSP_LINKS WHERE PROJ_ID = @cprog

               DELETE FROM MSP_NUMBER_FIELDS WHERE PROJ_ID = @cprog

               DELETE FROM MSP_OUTLINE_CODES WHERE PROJ_ID = @cprog

               DELETE FROM MSP_PROJECTS WHERE PROJ_ID = @cprog

               DELETE FROM MSP_RESOURCE_RATES WHERE PROJ_ID = @cprog

               DELETE FROM MSP_RESOURCES WHERE PROJ_ID = @cprog


               DELETE FROM MSP_TEXT_FIELDS WHERE PROJ_ID = @cprog


               DELETE FROM MSP_TIMEPHASED_DATA WHERE PROJ_ID = @cprog



               DELETE FROM PO_TASK_PBS_CODES WHERE PROJ_ID = @cprog


               DELETE FROM PO_LOG_TASKS WHERE PROJ_ID = @cprog

               DELETE FROM TAB_RESOURCE_ACTUAL_PHASING WHERE ASS_ID IN(SELECT ASS_ID FROM MSP_TASK_ASSIGNMENT_USERS WHERE PROJ_ID = @cprog )


               DELETE FROM TAB_RESOURCE_BASELINE_PHASING WHERE ASS_ID IN(SELECT ASS_ID FROM MSP_TASK_ASSIGNMENT_USERS WHERE PROJ_ID = @cprog )



               DELETE FROM TAB_RESOURCE_WORK_PHASING WHERE ASS_ID IN(SELECT ASS_ID FROM MSP_TASK_ASSIGNMENT_USERS WHERE PROJ_ID = @cprog )


               DELETE FROM MSP_TASK_ASSIGNMENT WHERE PROJ_ID = @cprog


               DELETE FROM MSP_TASK_ASSIGNMENT_USERS WHERE PROJ_ID = @cprog



               DELETE FROM Tab_Cost_Actual_Phasing WHERE ASS_ID IN(SELECT ASS_ID FROM Cost_Rev_Asso_Task WHERE PROJ_ID = @cprog )


               DELETE FROM Tab_Cost_Baseline_Phasing WHERE ASS_ID IN(SELECT ASS_ID FROM Cost_Rev_Asso_Task WHERE PROJ_ID = @cprog )



               DELETE FROM Tab_Cost_Work_Phasing WHERE ASS_ID IN(SELECT ASS_ID FROM Cost_Rev_Asso_Task WHERE PROJ_ID = @cprog )



               DELETE FROM Tab_Cost_ACCR_Phasing WHERE ASS_ID IN(SELECT ASS_ID FROM Cost_Rev_Asso_Task WHERE PROJ_ID = @cprog )


               DELETE FROM Tab_Cost_Expend_Phasing WHERE ASS_ID IN(SELECT ASS_ID FROM Cost_Rev_Asso_Task WHERE PROJ_ID = @cprog )


               DELETE FROM Cost_Rev_Asso_Task WHERE Proj_ID = @cprog

               DELETE FROM MSP_TASKS WHERE PROJ_ID = @cprog
                --Added by shivika for RQ-001512 on 7-Nov-2015
               DELETE FROM TAB_COST_BASELINE_PHASING_BAK where ASS_ID in (select ASS_ID from Cost_Rev_Asso_Task where PROJ_ID = @cprog )
               -- 'Ends Here
               -- 'DELETE FROM TAB_DOCUMENTS
               DELETE FROM TAB_DOC_FILEDETAIL WHERE DOC_ID IN (SELECT DOC_ID FROM TAB_DOCUMENTS WHERE REF_ID = @cprog )
               DELETE FROM TAB_DOCUMENTS WHERE REF_ID = @cprog
--               'DELETE FROM RISK
               DELETE FROM TAB_RISK_CONTROL WHERE RISK_ID IN (SELECT RISK_ID FROM TAB_RISK_MASTER WHERE C_PROG = @cprog )
               DELETE FROM TAB_RISK_ACTION_ASSO WHERE RISK_ID IN (SELECT RISK_ID FROM TAB_RISK_MASTER WHERE C_PROG = @cprog )
              DELETE FROM TAB_RISK_MASTER WHERE C_PROG = @cprog
--                'DELETE FROM S&G
               DELETE FROM SG_TAB_Models_ProjAsso WHERE C_PROG = @cprog
--                'DELETE FROM SERIES MANAGEMENT
               DELETE FROM ASCN_SERIES_PRJ WHERE C_PROG = @cprog
--                'DELETE FROM PROJECT RATES
               DELETE FROM TAB_PRJ_RATE_VALUES WHERE C_PROG = @cprog
               DELETE FROM TAB_PRJ_RATE WHERE C_PROG = @cprog
               DELETE FROM TAB_PRJ_RATE_CATALOG WHERE C_PROG = @cprog
--                'DELETE PROJECT CURRENCIES EXCHANGES
               DELETE FROM TAB_EXCHANGE_INTERVALS_PRJ WHERE C_PROG = @cprog
               DELETE FROM TAB_EXCHANGE_PRJ WHERE C_PROG = @cprog
--'DELETE FROM CALENDARS
               DELETE FROM LIGHT_CALENDARS WHERE UPPER(KEY_TYPE) = 'C_PROG' AND KEY_OBJ = @cprog
               DELETE FROM LIGHT_CALENDARS_EXCEPTIONS WHERE UPPER(KEY_TYPE) = 'C_PROG' AND KEY_OBJ = @cprog
-- MODULES CUSTOM ATTRIBUTES
               DELETE FROM CUSTOM_FIELDS_EXT_PRJ WHERE C_PROG = @cprog
--ROLES FOR PROJECT
               DELETE FROM ASCN_PRJ_TEAM_MODEL WHERE C_PROG = @cprog
--CROSSTAB, ATTRIBUTE
               DELETE FROM TAB_MAPPING_PRJ_CROSSTAB WHERE C_PROG = @cprog
               DELETE FROM TAB_MAPPING_PRJ_ATTRIBUTE WHERE C_PROG = @cprog

               DELETE FROM ORD_T131 WHERE C_PROG = @cprog
               DELETE FROM PROG_T056 WHERE C_PROG = @cprog
               DELETE FROM PROG_STA_STOR WHERE C_PROG = @cprog
               DELETE FROM PTI_T122 WHERE C_PROG = @cprog


               DELETE FROM SEQ_T039 WHERE C_PROG = @cprog


               DELETE FROM LIGHT_ASCN_OBS_DIP WHERE C_PROG = @cprog


               DELETE FROM LIGHT_ASCN_CBS_CLASSE_PRJ WHERE C_PROG = @cprog


               DELETE FROM SIMPLE_STRU_T088 WHERE C_PROG = @cprog


               DELETE FROM STRU_T087 WHERE C_PROG = @cprog


               DELETE FROM VER_BDG_T060 WHERE C_PROG = @cprog


               DELETE FROM VER_PTI_T120 WHERE C_PROG = @cprog


               DELETE FROM TAB_COLLAB_REL WHERE REL_TYPE = 'CA' AND 
			   (  ID1 IN (SELECT CHANGE_ID FROM TAB_CHANGE WHERE C_PROG = @cprog )
			    OR ID2 IN (SELECT ACT_ID FROM TAB_ACTIONS WHERE C_PROG = @cprog ))


               DELETE FROM TAB_COLLAB_REL WHERE REL_TYPE = 'CI' AND 
			   (  ID1 IN (SELECT CHANGE_ID FROM TAB_CHANGE WHERE C_PROG = @cprog )
			    OR ID2 IN (SELECT ISSUE_ID FROM TAB_ISSUE WHERE C_PROG = @cprog ))


               DELETE FROM TAB_COLLAB_REL WHERE REL_TYPE = 'IA' AND 
			   (  ID1 IN (SELECT ISSUE_ID FROM TAB_ISSUE WHERE C_PROG = @cprog )
			   OR ID2 IN (SELECT CHANGE_ID FROM TAB_CHANGE WHERE C_PROG = @cprog ))

               DELETE FROM TAB_ACTIONS WHERE C_PROG = @cprog


               DELETE FROM TAB_CHANGE WHERE C_PROG = @cprog



               DELETE FROM TAB_ISSUE WHERE C_PROG = @cprog

               DELETE FROM MSP_TASK_ASSIGNMENT_USERS_BAK WHERE PROJ_ID = @cprog

			   DELETE FROM ASCN_PROG_WF WHERE C_PROG = @cprog


               DELETE FROM ASCN_PROG_VER_MODEL WHERE C_PROG = @cprog



               DELETE FROM ASCN_PROG_ATT_CATALOG WHERE C_PROG = @cprog




               DELETE from TAB_TICKET_SCHEDULE where TICKET_ID in (SELECT TICKET_ID FROM  TAB_TICKETS WHERE C_PROG = @cprog )


               DELETE from TAB_TICKET_SCHEDULE_BAK where TICKET_ID in (SELECT TICKET_ID FROM  TAB_TICKETS WHERE C_PROG = @cprog )


               DELETE from TAB_TICKET_ATTACHMENT where TICKET_ID in (SELECT TICKET_ID FROM  TAB_TICKETS WHERE C_PROG = @cprog )


               DELETE from TAB_TICKET_ATTACHMENT_BAK where TICKET_ID in (SELECT TICKET_ID FROM  TAB_TICKETS WHERE C_PROG = @cprog )


               DELETE from TAB_TICKET_VERIFICATION where TICKET_ID in (SELECT TICKET_ID FROM  TAB_TICKETS WHERE C_PROG = @cprog )


               DELETE from TAB_TICKET_VERIFICATION_BAK where TICKET_ID in (SELECT TICKET_ID FROM  TAB_TICKETS WHERE C_PROG = @cprog )



               DELETE from TAB_TICKET_DOCS where TICKET_ID in (SELECT TICKET_ID FROM  TAB_TICKETS WHERE C_PROG = @cprog )



               DELETE from TAB_TICKETS_BAK WHERE C_PROG = @cprog
               DELETE from ASCN_REQUEST_OBJECT where OBJ_ID in (SELECT TICKET_ID FROM  TAB_TICKETS WHERE C_PROG = @cprog )
               DELETE from TAB_COMMENTS where TS_TYPE='TICKET' AND TS_ID in (SELECT TICKET_ID FROM  TAB_TICKETS WHERE C_PROG = @cprog )
               DELETE from TAB_COMMENTS_BAK where TS_TYPE='TICKET' AND TS_ID in (SELECT TICKET_ID FROM  TAB_TICKETS WHERE C_PROG = @cprog )
               DELETE from TAB_WF_STEP_RELEASE where OBJ_ID in (SELECT TICKET_ID FROM  TAB_TICKETS WHERE C_PROG = @cprog )

               DELETE from TAB_WF_PSTEP_RELEASE where OBJ_ID in (SELECT TICKET_ID FROM  TAB_TICKETS WHERE C_PROG = @cprog )

               DELETE FROM TAB_COLLAB_REL WHERE ( REL_TYPE IN ('TA','TC','TD','TR','TI') AND 
			    (  ID2 IN (SELECT TICKET_ID FROM TAB_TICKETS WHERE C_PROG = @cprog )))
				 OR ( REL_TYPE ='TT' AND ID1 IN (SELECT TICKET_ID FROM TAB_TICKETS WHERE C_PROG = @cprog ))

               DELETE from  TAB_COLLAB_MLSTN where C_PROG=@cprog

               DELETE from TAB_TICKETS WHERE C_PROG = @cprog
               DELETE from TAB_REQUESTS WHERE C_PROG = @cprog


                FETCH next FROM allProjectCur INTO @cprog 
        END

CLOSE allProjectCur 

      DEALLOCATE allProjectCur 


end try
begin catch
if @@TRANCOUNT > 0 
print @cprog + 'Project not Deleted'
ROLLBACK TRANSACTION;
end catch
if @@TRANCOUNT > 0 
COMMIT TRANSACTION;
END