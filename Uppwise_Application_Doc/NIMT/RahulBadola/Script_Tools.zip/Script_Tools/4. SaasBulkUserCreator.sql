
--select * from po_saas_customers
BEGIN
Declare @MaxUser integer, @cutomerId Integer
set @MaxUser = (select ISNULL(max(C_UTEN),0) from PO_SAAS_USERS) --115
set @cutomerId =108 --Nestle

--Insert into PO_SAAS_ASCN_CUSTOMERS_USERS (C_UTEN,CUSTOMER_ID)
--select ROW_NUMBER() over(order by u.c_user asc) as C_UTEN,103 as CUSTOMER_ID  from PO10_NestleBetaQA.dbo.UTEN_T017 u 
--left outer join PO10SaaS_Beta.dbo.PO_SAAS_USERS pu on u.C_USER = pu.C_USER where pu.C_USER is null

insert into PO_SAAS_USERS(C_USER,C_UTEN)
select u.C_USER ,ROW_NUMBER() over(order by u.c_user asc) + @MaxUser as C_UTEN  from SPMRenalCare_US.dbo.UTEN_T017 u 
left outer join dbo.PO_SAAS_USERS pu on u.C_USER = pu.C_USER where pu.C_USER is null

Insert into PO_SAAS_ASCN_CUSTOMERS_USERS (C_UTEN,CUSTOMER_ID)
SELECT p.c_uten, 
       @cutomerId as customer_id 
FROM   po_saas_users p 
       INNER JOIN SPMRenalCare_US.dbo.uten_t017 u 
               ON p.c_user = u.c_user 
       LEFT OUTER JOIN po_saas_ascn_customers_users sc 
                    ON sc.c_uten = p.c_uten 
                       AND sc.customer_id = @cutomerId 
WHERE  sc.c_uten IS NULL 

END 

