 --SaaS based OLEDB to SQLNativeClient
 
  update [PO_SAAS_CUSTOMERS] set conn_string = replace(conn_string,'SQLOLEDB.1','SQLNCLI11'),fms_conn_string =  replace(fms_conn_string,'SQLOLEDB.1','SQLNCLI11')


  update [PO_SAAS_CUSTOMERS] set conn_string = replace(conn_string,'SQLNCLI11','SQLOLEDB.1'),fms_conn_string =  replace(fms_conn_string,'SQLNCLI11','SQLOLEDB.1')
   update [PO_SAAS_CUSTOMERS] set conn_string = replace(conn_string,'Provider=SQLOLEDB.1;',''),fms_conn_string =  replace(fms_conn_string,'Provider=SQLOLEDB.1;','')
 