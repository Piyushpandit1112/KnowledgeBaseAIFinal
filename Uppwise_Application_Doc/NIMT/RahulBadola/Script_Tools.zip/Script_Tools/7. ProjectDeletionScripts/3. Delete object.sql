--Delete object
--Repalce object ID in place of @objid
Declare @objid as numeric(18,0)
DECLARE allObjectCur CURSOR read_only FOR 
        Select OBJ_ID from BPM_OBJECTS where obj_id in(217,
233,
297)

      --OPEN CURSOR.   
      OPEN allObjectCur 

      --FETCH THE RECORD INTO THE VARIABLES.   
      FETCH next FROM allObjectCur INTO @objid
	   WHILE @@FETCH_STATUS = 0 
	   BEGIN

		   DELETE FROM BPM_OBJECTS WHERE OBJ_ID IN(@objid)
           DELETE FROM TAB_ISSUE WHERE ISSUE_ID in (@objid)
           DELETE FROM TAB_ACTIONS WHERE ACT_ID in (@objid)
           DELETE FROM TAB_CHANGE WHERE CHANGE_ID in (@objid) 
           DELETE FROM TAB_RISK_MASTER WHERE Risk_ID in (@objid)
           DELETE FROM TAB_DOCUMENTS WHERE DOC_ID in (@objid)
           DELETE FROM TAB_TICKETS WHERE TICKET_ID in (@objid) 
           DELETE FROM MLSTN_CONTR_T119 WHERE OBJ_ID in (@objid) 
            --Delete backup tables data
           DELETE FROM BPM_OBJECTS_BAK WHERE OBJ_ID in (@objid)
           DELETE FROM TAB_ISSUE_BAK WHERE ISSUE_ID in (@objid)
           DELETE FROM TAB_ACTIONS_BAK WHERE ACT_ID in (@objid) 
           DELETE FROM TAB_CHANGE_BAK WHERE CHANGE_ID in (@objid)
           DELETE FROM TAB_RISK_MASTER_BAK WHERE Risk_ID in (@objid) 
           DELETE FROM TAB_DOCUMENTS_BAK WHERE DOC_ID in (@objid)
           DELETE FROM TAB_TICKETS_BAK WHERE TICKET_ID in (@objid)
           DELETE FROM BPM_LISTBOX_DATA_BAK WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_OPTIONS_DATA_BAK WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_COMBO_DATA_BAK WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_TEXTBOX_DATA_BAK WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_TEXTBOX_NUM_DATA_BAK WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_TEXTBOX_DATE_DATA_BAK WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_LOOKUP_DATA_BAK WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_ROLES_DATA_BAK WHERE OBJ_ID in (@objid) 
           DELETE FROM BPM_STRU_DATA_BAK WHERE OBJ_ID in (@objid) 
           DELETE FROM BPM_GUARANTEE_BAK WHERE OBJ_ID in (@objid) 
           DELETE FROM BPM_ACTION_COST_BAK WHERE OBJ_ID in (@objid) 
           DELETE FROM BPM_RISK_ANALYSIS_BAK WHERE RISK_ID in (@objid) 
           DELETE FROM BPM_RISK_CONTROL_BAK WHERE RISK_ID in (@objid) 
           DELETE FROM TAB_COMMENTS_BAK WHERE TS_ID in (@objid) 
           DELETE FROM MLSTN_CONTR_T119_BAK WHERE OBJ_ID in (@objid) 
           DELETE FROM MLSTN_CONTR_T119_BAK WHERE OBJ_ID in (@objid) 
           DELETE FROM BPM_VERIFICATION_BAK WHERE OBJ_ID in (@objid) 
           DELETE FROM BPM_SCHEDULE_DATES_BAK WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_LISTBOX_DATA WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_OPTIONS_DATA WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_COMBO_DATA WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_TEXTBOX_DATA WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_TEXTBOX_NUM_DATA WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_TEXTBOX_DATE_DATA WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_LOOKUP_DATA WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_COLLAB_REL WHERE ID1 in (@objid)  	--�(Relation & Dependency)
           DELETE FROM BPM_ROLES_DATA WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_STRU_DATA WHERE OBJ_ID in (@objid) 
           DELETE FROM BPM_VERIFICATION WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_GUARANTEE WHERE OBJ_ID in (@objid) 
           DELETE FROM BPM_ACTION_COST WHERE OBJ_ID in (@objid) 
           DELETE FROM BPM_RISK_ANALYSIS WHERE RISK_ID in (@objid) 
           DELETE FROM BPM_RISK_CONTROL WHERE RISK_ID in (@objid)
           DELETE FROM TAB_DOC_FILEDETAIL WHERE DOC_ID in (@objid) 
           DELETE FROM TAB_COMMENTS WHERE TS_ID in (@objid) 
           DELETE FROM TAB_WF_STEP_RELEASE WHERE OBJ_ID in (@objid)
           DELETE FROM BPM_SCHEDULE_DATES WHERE OBJ_ID in (@objid) 
		 DELETE FROM MSP_TASK_ASSIGNMENT_USERS_BAK WHERE OBJ_ID in (@objid) 
		 DELETE FROM MSP_TASK_ASSIGNMENT_USERS WHERE OBJ_ID in (@objid) 
		 DELETE FROM BPM_OBJECT_VISIBILITY WHERE OBJ_ID in (@objid)
		 
		 
 FETCH next FROM allObjectCur INTO @objid 
        END

CLOSE allObjectCur 

      DEALLOCATE allObjectCur 