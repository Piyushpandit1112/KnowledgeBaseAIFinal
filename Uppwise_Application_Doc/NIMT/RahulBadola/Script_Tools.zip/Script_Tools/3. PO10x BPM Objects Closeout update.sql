
Update bo set IS_CLOSEOUT =1 from BPM_OBJECTS_CLOSEOUT BOC inner join BPM_OBJECTS bo on boc.F_ID =bo.f_id and boc.OBJ_ID =bo.OBJ_ID

update  BPM_OBJECTS set IS_CLOSEOUT = 0 where IS_CLOSEOUT is null