declare @ASS_ID int
declare @seq  int
declare @idtab int
declare @VCA_ID int
declare @f_type nvarchar(max), @c_Azd int

set @ASS_ID =1
set @seq =9
set @idtab =19
set @f_type = 'IED'
set @c_Azd=2

select @VCA_ID=(max(vca_id)+1) from BPM_FORM_FIELD_MASTER WHERE  F_ID=10 AND F_TYPE=@f_type 
INSERT INTO ASCN_BPM_SECTION_CONTROLS VALUES(@ASS_ID,@idtab,5,	@seq,	@c_Azd,	0,	0,	@VCA_ID)
INSERT INTO BPM_FORM_FIELD_MASTER VALUES(@ASS_ID,	10,	@f_type,	5,	@idtab,@VCA_ID,@seq,	'EBS Binding',@c_Azd,	1,0)
