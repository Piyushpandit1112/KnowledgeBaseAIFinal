WITH cte AS (
    SELECT 
       [OBJ_ID] , [OBJ_OWNER], [ACCESS_TYPE] ,
        ROW_NUMBER() OVER (
            PARTITION BY 
               [OBJ_ID] , [OBJ_OWNER], [ACCESS_TYPE]
            ORDER BY 
                [OBJ_ID] , [OBJ_OWNER], [ACCESS_TYPE]
        ) row_num
     FROM 
        BPM_OBJECTS_ACCESS
)
--DELETE 
select * FROM cte
WHERE row_num > 1;