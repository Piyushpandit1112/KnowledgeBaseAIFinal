-- Script for truncating Volt DB 

return

select * from fmsfileinfoversion
select * from fmsfileData
select * from fmsfileDataBAK
select * from fmsfileinfo
select * from fmsfileinfoBAK

truncate table fmsfileData
truncate table fmsfileDataBAK
truncate table fmsfileinfo
truncate table fmsfileinfoBAK
truncate table fmsfileinfoversion

select * from fmsfileinfoversion
select * from fmsfileData
select * from fmsfileDataBAK
select * from fmsfileinfo
select * from fmsfileinfoBAK