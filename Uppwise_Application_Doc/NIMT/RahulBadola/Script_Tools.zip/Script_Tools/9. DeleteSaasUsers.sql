--select * from po_saas_users

--select * from po_saas_customers

--Provider=SQLNCLI11;Data Source=10.41.0.5;User ID=POIRE;Password=5335B5E31BD139DCA405;Initial Catalog=POxiAXA
-- Delete User from SAAS
delete from po_saas_users where c_uten in (select c_uten from  PO_SAAS_ASCN_CUSTOMERS_USERS where customer_id =123)
GO
Delete  from PO_SAAS_ASCN_CUSTOMERS_USERS where customer_id =123