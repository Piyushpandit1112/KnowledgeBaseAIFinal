select n.SYNC_DATE, EXT_INTEGRATION_PROJCODE, * from PROG_T056 p inner join NESTLE_SAP_SYNC_DATE n on p.c_prog =n.C_PROG --where p.c_prog =63101 

select * from NESTLE_SAP_SYNC_DATE where c_prog =2235


select * from NESTLE_PROJECTCREATE_SAPEXCEPTION where c_prog =60914

select * from TAB_NESTLE_BUDGET_RECORD where c_prog =63101

select * from Project_Cost_Sync_Details  where c_prog =57489

select * from BPM_WF_STEP_DETAILS where obj_id =1205909

select * from TAB_WF_STEP_RELEASE where obj_id =1205909

select * from TAB_Exception_Tracker
where DATEADD(dd, 0, DATEDIFF(dd, 0, E_Date)) = DATEADD(dd, 0, DATEDIFF(dd, 1, GETDATE())) 
and E_PageName like '%63101%'
order by E_Date desc


select distinct DATEADD(dd, 0, DATEDIFF(dd, 0, DATE_RELEASE)) from (
select p.C_PROG,p.EXT_INTEGRATION_PROJCODE,S_PROG_AZD_NOM,x.bdg,(select ISNULL(IS_LockSapIntegration,0) from TAB_FACILITY t where t.C_FACILITY =aob.c_facility) as ISSAPLOCK, t.* from PROG_T056 p 
inner join BPM_OBJECTS b on p.c_prog = b.c_prog and f_id =10
inner join ASCN_OBS_PROG AOB on AOB.C_PROG = p.C_PROG
inner join TAB_WF_STEP_RELEASE t on t.OBJ_ID = b.OBJ_ID and b.F_TYPE = 'CS'

outer apply(
select sum(I_BDG_REV) as bdg,C_PROG from COSTO_AGRT_T022 where c_prog = p.C_PROG and CE_TYPE= 'CAPEX'
group by C_PROG
) x

Outer apply(
select SAP_UPDATE_STATUS,SAP_SYSTEM_STATUS from TAB_EXTERNAL_ENTRIES where ChildID = p.C_PROG and ChildField = 'C_PROG' and entrytype =1 and ParentField ='C_FACILITY'
)y
where
--DATEADD(dd, 0, DATEDIFF(dd, 0, DATE_RELEASE)) = DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE())) and
 RELEASE_COMMENTS ='Workflow Completed'
and EXT_INTEGRATION_PROJCODE is null
and year(DATE_RELEASE) =2024 and ISNULL(bdg,0)<>0 


and p.c_prog =57489

select * from TAB_EXTERNAL_ENTRIES where ChildField =62111

select I_COMM,I_ACEM,I_STIMA_CMPL_1,I_COMM_CURR from COSTO_AGRT_T022  where c_prog in (
50779,
56364,
60753,
61976,
62946,
56608,
58162)

select * from BPM_OBJECTS where OBJ_CODE ='1043-23/0113'

select CE_TYPE,sum(I_BDG_REV),C_PROG from COSTO_AGRT_T022 where c_prog in (
60774,
56364,
60753,
61976,
62946,
56608,
58162
) --and EXT_INTEGRATION_COSTCODE is not null
group by CE_TYPE,C_PROG

select * from TAB_EXTERNAL_ENTRIES where ChildID = '50779' and ChildField = 'C_PROG' and entrytype =1

select * from NESTLE_PROJECTCREATE_SAPEXCEPTION where c_prog in (
56364,
56608,
60753,
60774,
58162,
61976,
62946
)