--- Active Transactions
sp_who active

--- Log and Data file name
sp_helpfile
--- 
dbcc inputbuffer(54)

--- Log Size ---
dbcc sqlperf(logspace)

--- Space used by DB ---
sp_spaceused;


---SHRINK Database ----
--to decreases the size of the data and log files in the UserDB database and to allow for 10 percent free space in the database.
DBCC SHRINKDATABASE (UserDB, 10);
------------------------


use PO8_ACN_PROD_22FEB17
go

alter database POxiNestleBetaQA set recovery simple
go
dbcc shrinkfile('xPO9NESTLE_Data',1000)
go
alter database POxiNestleBetaQA set recovery full


--- Blocked Transactions ---

select * from sys.sysprocesses where blocked <>0


select name as index_id,stats_date(object_id,index_id) as statsdate from sys.indexes order by 1 desc



--CHECK INDEX FRAGMENTATION ON INDEXES IN A DATABASE
SELECT DBSCHEMAS.[NAME] AS 'SCHEMA',DBTABLES.[NAME] AS 'TABLE',DBINDEXES.[NAME] AS 'INDEX',INDEXSTATS.AVG_FRAGMENTATION_IN_PERCENT,INDEXSTATS.PAGE_COUNT
FROM SYS.DM_DB_INDEX_PHYSICAL_STATS (DB_ID(), NULL, NULL, NULL, NULL) AS INDEXSTATS
INNER JOIN SYS.TABLES DBTABLES ON DBTABLES.[OBJECT_ID] = INDEXSTATS.[OBJECT_ID]
INNER JOIN SYS.SCHEMAS DBSCHEMAS ON DBTABLES.[SCHEMA_ID] = DBSCHEMAS.[SCHEMA_ID]
INNER JOIN SYS.INDEXES AS DBINDEXES ON DBINDEXES.[OBJECT_ID] = INDEXSTATS.[OBJECT_ID] AND INDEXSTATS.INDEX_ID = DBINDEXES.INDEX_ID
WHERE INDEXSTATS.DATABASE_ID = DB_ID() and DBTABLES.[NAME]  = 'PCM_DSBN_COST'
ORDER BY INDEXSTATS.AVG_FRAGMENTATION_IN_PERCENT DESC


---- Statistics

select *, name ,STATS_DATE(OBJECT_ID,stats_ID) from sys.stats

--HOW OLD ARE YOUR DATABASE STATISTICS?
SELECT O.NAME,I.NAME AS [INDEX NAME],STATS_DATE(I.[OBJECT_ID], I.INDEX_ID) AS [STATISTICS DATE],S.AUTO_CREATED,S.NO_RECOMPUTE,S.USER_CREATED
FROM SYS.OBJECTS AS O WITH (NOLOCK)
INNER JOIN SYS.INDEXES AS I WITH (NOLOCK) ON O.[OBJECT_ID] = I.[OBJECT_ID]
INNER JOIN SYS.STATS AS S WITH (NOLOCK) ON I.[OBJECT_ID] = S.[OBJECT_ID] AND I.INDEX_ID = S.STATS_ID
WHERE O.[TYPE] = 'U'
ORDER BY STATS_DATE(I.[OBJECT_ID], I.INDEX_ID) Desc;