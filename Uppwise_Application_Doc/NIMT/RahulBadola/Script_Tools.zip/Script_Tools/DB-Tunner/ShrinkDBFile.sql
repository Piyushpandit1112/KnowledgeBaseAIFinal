sp_helpfile

go
use ReportingAPI_POxiArtesysOrion
alter database ReportingAPI_POxiArtesysOrion set recovery simple
go
dbcc shrinkfile('ReportingPowerBI_log',500)
go
alter database ReportingAPI_POxiArtesysOrion set recovery full