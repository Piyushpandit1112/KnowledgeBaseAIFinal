DECLARE @Database NVARCHAR(255)   
DECLARE @Table NVARCHAR(255) 
Declare @Fragperc numeric(18,2)
DECLARE @cmd NVARCHAR(1000)  

DECLARE DatabaseCursor CURSOR READ_ONLY FOR  
SELECT name FROM master.sys.databases   
WHERE name IN ('SPMProdSella_B')--NOT IN ('master','msdb','tempdb','model','distribution')  -- databases to exclude
--WHERE name IN ('DB1', 'DB2') -- use this to select specific databases and comment out line above
AND state = 0 -- database is online
AND is_in_standby = 0 -- database is not read only for log shipping
ORDER BY 1  

OPEN DatabaseCursor  

FETCH NEXT FROM DatabaseCursor INTO @Database  
WHILE @@FETCH_STATUS = 0  
BEGIN  


DECLARE TableCursor CURSOR READ_ONLY FOR
SELECT
dbtables.[name] as 'Table',
indexstats.avg_fragmentation_in_percent
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL) AS indexstats
INNER JOIN sys.tables dbtables on dbtables.[object_id] = indexstats.[object_id]
INNER JOIN sys.schemas dbschemas on dbtables.[schema_id] = dbschemas.[schema_id]
INNER JOIN sys.indexes AS dbindexes ON dbindexes.[object_id] = indexstats.[object_id]
AND indexstats.index_id = dbindexes.index_id
WHERE indexstats.database_id = DB_ID() and avg_fragmentation_in_percent >5
ORDER BY indexstats.avg_fragmentation_in_percent desc  
   OPEN TableCursor   

   FETCH NEXT FROM TableCursor INTO @Table  ,@Fragperc 
   WHILE @@FETCH_STATUS = 0   
   BEGIN
      BEGIN TRY   
         SET @cmd = 'ALTER INDEX ALL ON ' + @Table  --Rebuild
		 if @Fragperc  > 5 AND @Fragperc < 30 
		 BEGIN
		SET @cmd += ' REORGANIZE'
		 END
		 ELSE
		 BEGIN
		 SET @cmd += ' rebuild'
		 END
         PRINT @cmd -- uncomment if you want to see commands
        -- EXEC (@cmd) 
      END TRY
      BEGIN CATCH
         PRINT '---'
         PRINT @cmd
         PRINT ERROR_MESSAGE() 
         PRINT '---'
      END CATCH

      FETCH NEXT FROM TableCursor INTO @Table,@Fragperc  
   END   

   CLOSE TableCursor   
   DEALLOCATE TableCursor  

   FETCH NEXT FROM DatabaseCursor INTO @Database  
END  
CLOSE DatabaseCursor   
DEALLOCATE DatabaseCursor