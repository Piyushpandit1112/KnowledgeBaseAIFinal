--drop table #UTEN_PROG_FILTER

--select * from #UTEN_PROG_FILTER

--select Distinct C_PROG , 40707154155540 C_UTEN into #UTEN_PROG_FILTER FROM BPM_OBJECTS M where 1 = 1 and f_id =  10 and F_type = 'FP' 
--and
----select * from ascn_obs_prog where
--c_prog in (3771,2685
--,2689
--,2742
--,2820
--,2859
--,2942
--,2955)


select Distinct C_PROG , 80125112841950 as  C_UTEN into #UTEN_PROG_FILTER FROM
 BPM_OBJECTS M where 1 = 1 and f_id =10 and f_type = 'RP'

DECLARE @oTotalObjects         AS INT, 
        @oActiveObjects        AS INT, 
        @oMyObjects            AS INT, 
        @oCreatorForDynFilters AS NVARCHAR 

EXEC Bpmobjectsregisterdatajson 
  10, 
  'RP', 
  1, 
  80125112841950, 
  -1, 
  2, 
  '#UTEN_PROG_FILTER', 
null, 
3, 
1, 
-1, 
'', 
'COS', 
72623, 
@oTotalObjects, 
@oActiveObjects, 
@oMyObjects, 
@oCreatorForDynFilters 


PRINT @oTotalObjects 
PRINT @oActiveObjects
PRINT @oMyObjects
PRINT @oCreatorForDynFilters 