SELECT TOP 50
db_name(CONVERT(int, dep.value)) AS dbname,
st.text,
SUBSTRING(st.text, (qs.statement_start_offset/2) + 1,  
    ((CASE statement_end_offset   
        WHEN -1 THEN DATALENGTH(st.text)  
        ELSE qs.statement_end_offset
    END - qs.statement_start_offset)/2) + 1
) AS statement_text,
qp.query_plan,
qs.execution_count,
qs.last_execution_time,
qs.last_worker_time/1000000.0 AS last_worker_time_s, --this is CPU time
qs.last_elapsed_time/1000000.0 AS last_elapsed_time_s --this is clock time
FROM sys.dm_exec_query_stats qs  
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st
CROSS APPLY sys.dm_exec_plan_attributes(qs.plan_handle) dep
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) qp
WHERE last_execution_time > DATEADD(day,-15,GETDATE()) --last 15 days
and dep.attribute = N'dbid' and db_name(CONVERT(int, dep.value)) <> 'master'
and (
	st.text not like N'DECLARE @projectID INT = -1%' AND
	st.text not like N';with MonthlyPhasing as%' AND
	st.text not like N'DECLARE @MonthlyPhasing as TABLE%' AND
	st.text not like N'SELECT TOP 50 db_name(CONVERT(int, dep.value))%' AND
	st.text not like N'DECLARE @firstDay as datetime%'
)
ORDER BY qs.last_elapsed_time DESC

