/*
 AUTH           - RISHU RANJAN 
 REQUEST & DATE - XRQ-000017 ON 27TH JUNE,2019
 DESC           - SCRIPT NO 1,2,3 FOR  : TO ADD PROCESS, SECTION, TAB NECESSARY FOR VERSION RELEASE FORM\
                  SCRIP NO 4,5    FOR  : TO CREATE TABLE TO STORE DATA NECESSARY FRO VERSION MANAGEMENT
				  SCRIPT NO 6     FOR  : USER CONTROL ENTRY FOR VERSION MANAGEMENT
                  
*/

--1. To create Process - Version 
Insert into BPM_FORM_TYPE VALUES ('VERSION','Version Release')

--2. To create Tab - Attachments
Insert into BPM_FORM_TAB VALUES (2,'ATT','Attachments',0)

--3. To create Section - Version Details & Attachments

Insert into BPM_SECTION_LIBRARY VALUES (1,'ATTACHEMENTS','ATTACHEMENTS',0)
Insert into BPM_SECTION_LIBRARY VALUES (2,'Version Details','Version Details',5)


--4. To create table necessary for version management

CREATE TABLE [dbo].[APP_TOL_T101](
	[C_VER] [numeric](18, 0) NOT NULL,
	[VER_NO] [nvarchar](200) NOT NULL,
	[D_VER] [datetime] NOT NULL,
	[UTEN_VER] [numeric](18, 0) NOT NULL,
	[VER_TYPE] [nvarchar](200) NULL,
	[VER_REASON] [nvarchar](max) NULL,
	[VER_FUNC_DETAILS] [nvarchar](max) NULL,
	[VER_COMMENT] [nvarchar](1000) NULL,
	[BPM_OBJ_ID] [numeric](18, 0) NULL
) ON [PRIMARY]

GO



--5. To create table necessary for relation between request & version

CREATE TABLE [dbo].[ASCN_APPTOL_REQ](
	[C_VER] [numeric](18, 0) NOT NULL,
	[REQUEST_ID] [nvarchar](50) NOT NULL,
	ver_seq bigint
) ON [PRIMARY]

GO

--6. Add value in user control for version management
INSERT INTO BPM_USERCONTROLS SELECT 193 , 	'Application Version details' ,	'APPVR' , 	'~/ucappversiondetails.ascx' ,	5	, 1 , 1, NUll

--7. Add workflow status - same as PO9
INSERT [dbo].[TAB_WF_STATUS] ([S_ID], [S_CODE], [S_DSC], [C_AZD]) VALUES (1, N'01', N'Opened', CAST(2 AS Numeric(18, 0)))
GO
INSERT [dbo].[TAB_WF_STATUS] ([S_ID], [S_CODE], [S_DSC], [C_AZD]) VALUES (2, N'02', N'Assigned', CAST(2 AS Numeric(18, 0)))
GO
INSERT [dbo].[TAB_WF_STATUS] ([S_ID], [S_CODE], [S_DSC], [C_AZD]) VALUES (3, N'03', N'Completed', CAST(2 AS Numeric(18, 0)))
GO
INSERT [dbo].[TAB_WF_STATUS] ([S_ID], [S_CODE], [S_DSC], [C_AZD]) VALUES (4, N'04', N'Accepted and Closed', CAST(2 AS Numeric(18, 0)))
GO



